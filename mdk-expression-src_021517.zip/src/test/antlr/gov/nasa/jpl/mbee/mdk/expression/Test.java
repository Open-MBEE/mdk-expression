package antlr.gov.nasa.jpl.mbee.mdk.expression;

import java.util.ArrayList;
import java.util.List;

public class Test {

	public Test(){
		
	}
	public List<Object> zz(List<Object> mainList){
		
		MyClass a = new MyClass("a");
		MyClass b = new MyClass("b");
		mainList.add(a);
		mainList.add(b);
		return mainList;
	}
	public static void main(String[] xx){
		
		List<Object> mainList = new ArrayList<Object>();
		System.out.println(mainList.size());
		
		Test xx1 = new Test();
		mainList = xx1.zz(mainList);
		
		System.out.println(mainList.size());
		System.out.println(mainList.size());
		
	}
	public class MyClass
	{
		String name;
		public MyClass(String _name) {
			name = _name;
		}
	}	
	
	
	
	
}

