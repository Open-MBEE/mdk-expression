package gov.nasa.jpl.mbee.mdk.expression;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.antlr.v4.runtime.tree.ParseTree;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.nomagic.magicdraw.core.Application;
import com.nomagic.uml2.ext.magicdraw.classes.mdkernel.ElementValue;
import com.nomagic.uml2.ext.magicdraw.classes.mdkernel.Expression;
import com.nomagic.uml2.ext.magicdraw.classes.mdkernel.LiteralInteger;
import com.nomagic.uml2.ext.magicdraw.classes.mdkernel.LiteralReal;
import com.nomagic.uml2.ext.magicdraw.classes.mdkernel.LiteralString;
import com.nomagic.uml2.ext.magicdraw.classes.mdkernel.ValueSpecification;


public class Doc2InfixString  extends Tree2UMLExpression {

	Document root;
	String print = "";
	
	private final String INFIX = "mfrac msub msup";
	
	private boolean skipNextmn = false;
	private boolean skipNextmi = false;
	private boolean previousWasCustom = false;
	
	public Doc2InfixString(MathEditorMain1Controller _controller, Document _root){
		super(_controller, null, null);
		this.root = _root;
	}
	@Override
	protected ValueSpecification traverse0(ParseTree n) throws Exception { 
	    //DocumentElement document = DOMBuilder.getInstance().createJeuclidDom(root, true, true);
	    return(traverse0x(root));
	}
	protected ValueSpecification traverse0x(Node n) throws Exception {
		
		Expression exp = getExpression();
		for ( int i = 0; i < n.getChildNodes().getLength(); i++){
			if ( n.getChildNodes().item(i).getNodeName().equals("math"))
				return processNode(n.getChildNodes().item(i), exp);
		}
		return null;
	}
	/*
	protected ValueSpecification traverse0x(Node n) throws Exception {
	    
	    while ( n.getNodeType() != Node.ELEMENT_NODE){
	    	NodeList nl = n.getChildNodes();
	 	    for (int i = 0; i < nl.getLength(); i++) {
	 	           n = nl.item(i);
	 	    }
	    }
	    if(n.getNodeType()==Node.ELEMENT_NODE) {
	        print += "\n" +"<"+n.getNodeName()+">";
	        String currentNode = n.getNodeName();
	        
	        if ( currentNode.equals("mo")){ //operator
	        	String moValue = n.getFirstChild().getNodeValue();
	        	if ( moValue.equals("-") || moValue.equals("+")){ //check if prefix by + or - number
	        		Node sibiling = nextElementNodeSibilig(n);
	        		if ( sibiling.getNodeName().equals("mn")){ //number
	        			skipNextmn = true;
	        			return getNumber(sibiling, moValue);
	        		}
	        	}
	        	else if ( moValue.equals("(") || moValue.equals("[")|| moValue.equals("{") || moValue.equals("(:") || moValue.equals("{:")  //leftbrackets       
	        			|| moValue.equals(")") || moValue.equals("]") ||moValue.equals("}") ||moValue.equals(":") ||moValue.equals("':") //right brackets 
	        			|| moValue.equals(",") ){  
	        		return createBracket(moValue);
	        	}
	        	//not negative number or bracket
	        	//Expression exp = super.getExpression();
    			ElementValue elemVal = createElementValueFromOperation(toStringFromUnicodeMO(moValue), null);
    			return elemVal; //return operator
	        }
	        else if ( currentNode.equals("mn")){
	        	if ( !skipNextmn){
	        		return getNumber(n, ""); //positive integer or real
	        	}
	        	else {
	        		skipNextmn = false;//reset (mn is precided with mo(-))
	        		return null;
	        	}
			}
	        else { //math mrow etc...
	        	System.out.println("Create Expression:" + currentNode);
	        	Expression exp = super.getExpression();
				
	        	//process children here
	        	if (INFIX.contains(n.getNodeName())){//Infix type msup msubsup msub
	        		NodeList nl = n.getChildNodes();
	        		String variableString = "";
		        	for (int i = 0; i < nl.getLength(); i++) {
		        		//child is mi - should be
		        		if (nl.item(i).getNodeType() == Node.ELEMENT_NODE){ //<msubsup> <mi>z</mi><mn>12</mn>   <mn>34</mn></msubsup>
		        			if (nl.item(i).getNodeName().equals("mi")) {
		        				variableString+=nl.item(i).getFirstChild().getNodeValue();
		        			}
		        			else if (nl.item(i).getNodeName().equals("mn")){ //number
		        				//for previous mi(s)
		        				if ( variableString.length() != 0 ){ //in case previous child is mi so variableString.length != 0
		        					exp = createExpression_handleSpecialmrowmi(n, exp, variableString);
		            				variableString = "";//reset
		        				}
		        				exp.getOperand().add(getNumber(nl.item(i), ""));
		        			}
		        			else if ( nl.item(i).getNodeName().equals("mrow")){
		        				//number 11.7: <mn>11.7</mn> -11.7(2nd variable): <mrow><mo>-</mo><mn>11.7</mn></mrow>  -11.7^x: <mo>-</mo><msup><mn>11.7</mn><mi>x</mi>

		        				//variable xy: <mrow><mo>(</mo><mi>x</mi><mi>y</mi><mo>)</mo></mrow> y: <mi>y</mi>   -x in 2nd variable: <mrow> <mo>-</mo> <mi>x</mi> </mrow>
		        		      
		        			}
		        			
		        			else { //TODO: can be mwrow?
		        				showMessage("Not supported for " + nl.item(i).getNodeName() + " for msup, msub, or msubsup");
		        				return null;
		        			}
		        			
		        			if ( i == 0 && exp.getOperand().size() == 1){ //<msub><mi>z</mi><mn>5</mn>
		        				exp = createAndAddElementValueToExpression_asciiMathLibraryBlock(exp, Doc2InfixStringUtil.INFIX.get(n.getNodeName()));
		        			}
		        			//TODO support msubsup having <msubsup><mi>a</mi><mi>b</mi><mn>5</mn></msubsup>
		        			else if ( n.getNodeName().equals("msubsup") &&  i == 1 )
		        				exp = createAndAddElementValueToExpression_asciiMathLibraryBlock(exp, "^");
	            		}
		        	} 
		        	//for child mi(s) last child was mi
		        	if ( variableString.length() != 0 ){ //in case previous child is mi so variableString.length != 0
    					exp = createExpression_handleSpecialmrowmi(n, exp, variableString);
        				//variableString = "";//not necessary
    				}
	    			return exp;
	        	}//end of if n is INFIX
	        	else {
	        		ValueSpecification vs;
	        		NodeList nl = n.getChildNodes();
	        		String variableString = "";
	        		String childNodeName;
	        		for ( int i = 0; i < nl.getLength(); i++) {
	        			//if not Node.ELEMENT_NODE then ignore
	        			if (nl.item(i).getNodeType() == Node.ELEMENT_NODE){ //<msubsup> <mi>z</mi><mn>12</mn>   <mn>34</mn></msubsup>
	        				childNodeName = nl.item(i).getNodeName();
		        			if (childNodeName.equals("mi")) {
		        				if ( !skipNextmi)
		        					variableString+=nl.item(i).getFirstChild().getNodeValue();
		        				else //skipping mi
		        					skipNextmi = false;
		        			}
		        			else {
		        				if ( variableString.length() != 0 ){ //in case previous child is mi so variableString.length != 0
		        					exp = createExpression_handleSpecialmrowmi(n, exp, variableString);
			        				variableString = "";//reset
		        				}
	        					
		        				vs = traverse0x(nl.item(i));
		        				if ( vs != null) {
		        					//TODO previousWasCustom does not work if previousCustom is nested.....
		        					if ( previousWasCustom && nl.item(i).getNodeName().equals("mrow") && skipNextmi == false){
		        						ValueSpecification previousCustomFunctionFunction = exp.getOperand().get(exp.getOperand().size() - 1); //get last elementValue for customFunction
		        						if (previousCustomFunctionFunction instanceof ElementValue || previousCustomFunctionFunction instanceof Expression){
		        							//remove old one
		        							exp.getOperand().remove(exp.getOperand().size() - 1);
		        							//create new Expression
		        							Expression newExp = super.getExpression();
		        							if (previousCustomFunctionFunction instanceof ElementValue)
		        								newExp.getOperand().add(previousCustomFunctionFunction); //adding in newExp before removing from exp will remove previousCustomFunctionElementValue automatically from exp witout explicitly call remove
		        							else
		        								newExp.getOperand().add(((Expression) previousCustomFunctionFunction).getOperand().get(0)); //adding in newExp before removing from exp will remove previousCustomFunctionElementValue automatically from exp witout explicitly call remove
		        							newExp.getOperand().add(vs);//customFunction's arguments (a,b,c)
		        							//add new Expression
		        							exp.getOperand().add(newExp);
		        							previousWasCustom = false;//reset
		        						}
		        					}
		        					else
		        						exp.getOperand().add(vs);
		        				}
		        			}
		        		}
	        		}//end of child loop
	        		if ( variableString.length() != 0){ //last of childnode mi so variableString.length() != 0
	        			exp = createExpression_handleSpecialmrowmi(n, exp, variableString); //thrown exception if not found in constraint parameter or customFunction
	        		}
	        		return exp;
	        	}
	        }//end of else
	    }
	    return null;
	}
	*/
	private List<Node> getChildElementNodes(Node n)
	{
		List<Node> elementNodes = new ArrayList<Node>();
		NodeList nl = n.getChildNodes();
		Node nc;
 	    for (int i = 0; i < nl.getLength(); i++) {
 	           nc = nl.item(i);
 	           if (nc.getNodeType() == Node.ELEMENT_NODE){
 	        	   elementNodes.add(nc);
 	           }
 	    }
 	    return elementNodes;
	}
	private String getPositiveOrNegativeNumber(List<Node>nl, int startIndex)
	{
		String s = "";
		if ( nl.size() == 2 && nl.get(startIndex).getNodeName().equals("mo") && (nl.get(startIndex).getFirstChild().getNodeValue().equals("-") || nl.get(startIndex).getFirstChild().getNodeValue().equals("+"))){
			s+=nl.get(startIndex).getFirstChild().getNodeValue(); //+ or -
			if ( nl.get(startIndex+1).getNodeName().equals("mn")) { //number prefix with "+" or "-"
				s+= nl.get(startIndex+1).getFirstChild().getNodeValue();
				return s;
			}
		}
		return null;
	}
	private String getMis(List<Node> nl, int startIndex)
	{
		String s = "";
		for ( int i = startIndex; i < nl.size(); i++){
			if( nl.get(i).getNodeName().equals("mi"))
				s+= nl.get(i).getFirstChild().getNodeValue();
			else
				break;
		}
		return s;
	}
	
	private Expression processNode(Node n, Expression exp) throws Exception{
		
		List<Node> nl = getChildElementNodes(n);
		int startIndex = 0;
		String v;
		for ( int i = startIndex; i < nl.size(); i++ ){
			if ( nl.get(i).getNodeName().equals("mn")) //number
				exp.getOperand().add(getNumber(nl.get(i), "")); //nextIndex = i+1 automatically
			else if((v = getPositiveOrNegativeNumber(nl, i)) != null){ //number prefix by + or -
				exp.getOperand().add(getNumber(v));
				i++;
			} else if ( nl.get(i).getNodeName().equals("mo")) {//operator
				Expression expNew = createAndAddElementValueToExpression_brackets(exp, nl.get(i).getFirstChild().getNodeValue()); //brackets and comma do not need conversion
				if ( expNew != null) //it was bracket or comma
					exp = expNew;
				else {
					exp = createAndAddElementValueToExpression_asciiMathLibraryBlock(exp, toStringFromUnicodeMO(nl.get(i).getFirstChild().getNodeValue()));
					if (exp == null){
						throw new Exception(toStringFromUnicodeMO(nl.get(i).getNodeValue()) + " is not in Library");
					}
				}
			}
			else if ( nl.get(i).getNodeName().equals("mi")){
				v = getMis(nl, i);
				if ( v.length() == 1) {
					if ( v.equals("f")|| v.equals("g")){ //are <mi> tagged
						exp = createAndAddElementValueToExpression_asciiMathLibraryBlock(exp, v);
						if ( exp == null)
							throw new Exception (v + " should be defined in AsciiMathLibraryBlock.  Define it and please retry.");
					}
					else
						v = this.toStringFromUnicodeMI(v);
				}
				//search from constraintblock
				Expression exp2 = createAndAddElementValueToExpression_constraintParameter(exp, v);
				if ( exp2 == null) {//may be customFunction
					exp2 = createAndAddElementValueToExpression_customFunction(exp, v);
					if (exp2 == null)
						throw new Exception (v + " is not a constraint parameter or custom function.");
					else
						exp = exp2; //is custom function
				}
				else
					exp = exp2; //is constraint parameter
				i = i + v.length()-1;
			}
			else if (nl.get(i).getNodeName().equals("mrow")){
				Expression expNew = getExpression();
				expNew = processNode(nl.get(i), expNew);
				if ( expNew == null)
					throw new Exception ("Not supported - problem in mrow");
				else {
					//check if need to add ()
					if ( needBrackets(nl.get(i))){
						Expression expNewNew = getExpression();
						expNewNew.getOperand().add(createBracket("("));
						expNewNew.getOperand().add(expNew);
						expNewNew.getOperand().add(createBracket(")"));
						exp.getOperand().add(expNewNew);
					}
					else
						exp.getOperand().add(expNew);
				}
			}
			else if ( Doc2InfixStringUtil.COMMAND_W_ARGS.get(nl.get(i).getNodeName()) == Doc2InfixStringUtil.TType.INFIX) {//.equals("msub") || nl.get(i).getNodeName().equals("msup")){
				Expression expNew = getExpression();
				expNew = processNode(nl.get(i), expNew);
				if ( expNew == null)
					throw new Exception ("Not supported - problem in " + nl.get(i).getNodeName());
				else if ( expNew.getOperand().size() != 2){
					throw new Exception ("Not supported - problem in " + nl.get(i).getNodeName() + " The function should have two arguments.");
				}
				else {
					//adding "^" or "-" to expNew (ab to a^b or a_b)
					ValueSpecification exp1 = expNew.getOperand().get(1);
					expNew.getOperand().remove(1);
					expNew = createAndAddElementValueToExpression_asciiMathLibraryBlock(expNew, Doc2InfixStringUtil.FN.get(nl.get(i).getNodeName()));
					expNew.getOperand().add(exp1);
					exp.getOperand().add(expNew);
				}
			}
			else if ( Doc2InfixStringUtil.COMMAND_W_ARGS.get(nl.get(i).getNodeName()) == Doc2InfixStringUtil.TType.UNARY) {//msqrt 
				Expression expNew = getExpression();
				expNew = createAndAddElementValueToExpression_asciiMathLibraryBlock(expNew, Doc2InfixStringUtil.FN.get(nl.get(i).getNodeName()));
				expNew = processNode(nl.get(i), expNew);
				if ( expNew == null)
					throw new Exception ("Not supported - problem in " + nl.get(i).getNodeName());
				else if ( expNew.getOperand().size() != 2){
					throw new Exception ("Not supported - problem in " + nl.get(i).getNodeName() + " The function should have one argument.");
				}
				else {
					exp.getOperand().add(expNew);
				}
			}
			else if ( Doc2InfixStringUtil.COMMAND_W_ARGS.get(nl.get(i).getNodeName()) == Doc2InfixStringUtil.TType.BINARY) {//root 
				Expression expNew = getExpression();
				expNew = createAndAddElementValueToExpression_asciiMathLibraryBlock(expNew, Doc2InfixStringUtil.FN.get(nl.get(i).getNodeName()));
				expNew = processNode(nl.get(i), expNew);
				if ( expNew == null)
					throw new Exception ("Not supported - problem in " + nl.get(i).getNodeName());
				else if ( expNew.getOperand().size() != 3){
					throw new Exception ("Not supported - problem in " + nl.get(i).getNodeName() + " The function should have one argument.");
				}
				else {
					exp.getOperand().add(expNew);
				}
			}
			else if ( Doc2InfixStringUtil.COMMAND_W_ARGS.get(nl.get(i).getNodeName()) == Doc2InfixStringUtil.TType.MOVERUNDER) {//
				Expression expNew = getExpression();
				expNew = processNode(nl.get(i), expNew);
				if ( expNew == null)
					throw new Exception ("Not supported - problem in " + nl.get(i).getNodeName());
				else if ( expNew.getOperand().size() != 2){
					throw new Exception ("Not supported - problem in " + nl.get(i).getNodeName() + " The function should have two arguments.");
				}
				else {
					//flip exp
					ValueSpecification exp1 = expNew.getOperand().get(0);
					ValueSpecification exp2 = expNew.getOperand().get(1);
					expNew.getOperand().clear();
					expNew.getOperand().add(exp2); 
					expNew.getOperand().add(exp1);
					exp.getOperand().add(expNew);
				}
			}
			else if (nl.get(i).getNodeName().equals("msubsup")){
				Expression expNew = getExpression();
				expNew = processNode(nl.get(i), expNew);
				if ( expNew == null)
					throw new Exception ("Not supported - problem in msubsup");
				else if ( expNew.getOperand().size() != 3){
					throw new Exception ("Not supported - problem in msubsup - childrens should be 3.");
				}
				else {
					
					//adding "_" or "^" to expNew  (abc to a_b^c)
					ValueSpecification exp1 = expNew.getOperand().get(1);
					ValueSpecification exp2 = expNew.getOperand().get(2);
					expNew.getOperand().remove(1); //removing exp1
					expNew.getOperand().remove(1); //removing exp2
					expNew = createAndAddElementValueToExpression_asciiMathLibraryBlock(expNew, "_");//"^ or "_"
					expNew.getOperand().add(exp1);
					expNew = createAndAddElementValueToExpression_asciiMathLibraryBlock(expNew, "^");//"^ or "_"
					expNew.getOperand().add(exp2);
					exp.getOperand().add(expNew);
				}
			}
		}
		return exp;
	}
	//TODO may need to imporive
	private boolean needBrackets(Node n){
		List<Node> nl = getChildElementNodes(n);
		if ( nl.size() == 1)
			return false;
		else
			return true;
//		if ( nl.get(0).getNodeName().equals("mo") && isBracket(nl.get(0).getFirstChild().getNodeValue()))//1st mrow child is a bracket "(" etc..
//			return false;
//		else if ( isAllChildrenHaveSameNodeName(n))
//			return false;
//		else {
//			String s = getPositiveOrNegativeNumber(nl, 0);
//			if ( s!= null && s.length() == nl.size())
//				return false; //it is positive or negative number
//			if ( nl.get(0).getNodeName().equals("mo") && (nl.get(0).getFirstChild().getNodeValue().equals("-")||nl.get(0).getFirstChild().getNodeValue().equals("+"))){
//				s = getMis(nl, 1); //variable prefix by - or +
//				if ( s.length() == 2 /*-a or +a*/ && s.length() == nl.size())
//					return false;
//				else if ( (s.length()+1) == nl.size())
//					return true; //(-ab)
//			}
//			return false; //ab+c <mrow><msub><mi>a</mi><mi>b<mi></msub><mrow> a_b
//		}
	}
	private boolean isAllChildrenHaveSameNodeName(Node n){
		List<Node> nl = getChildElementNodes(n);
		String firstNodeName = nl.get(0).getNodeName();
		for (int i = 1; i < nl.size(); i++){
			if ( !nl.get(i).getNodeName().equals(firstNodeName))
				return false;
		}
		return true;
	}
		/*
		
		if ( nl.get(0).getNodeName().equals("mo")) { // - or +
			if ( nl.get(1).getNodeName().equals("mn"))
				exp.getOperand().add(getNumber(nl.get(1), nl.get(0).getNodeValue())); //- or + number
			else if (nl.get(1).getNodeName().equals("mi")){ // - or + varaiables mi(s)
				String s = getMis(nl, 1);
				exp = createAndAddElementValueToExpression_asciiMathLibraryBlock(exp, toStringFromUnicodeMI(s));
				int nextIndex = s.length();
			}
		}
		
		
		
		if ( aChildRowsChildrens.get(0).getNodeName() == "mo"){ //- or +
				//negative number or positive number
				if ( aChildRowsChildrens.get(1).getNodeName() == "mn"){ //negativeNumber or positiveNumber
					exp.getOperand().add(getNumber(aChildRowsChildrens.get(1),aChildRowsChildrens.get(0).getNodeValue()));
				}
				else if ( aChildRowsChildrens.get(1).getNodeName() == "mi") { //negative or positive variable mi(s)
					for ( int i = 1; i < aChildRowsChildrens.size(); i++)
						variableName+=aChildRowsChildrens.get(i).getNodeValue();
					if (aChildRowsChildrens.size() >= 3 ) {//i.e., -ab ???????? surrend by ()
						exp.getOperand().add(createBracket("("));
						exp = createAndAddElementValueToExpression_asciiMathLibraryBlock(exp, aChildRowsChildrens.get(0).getNodeValue());
						exp = createAndAddElementValueToExpression_constraintParameter(exp, variableName);
						exp.getOperand().add(createBracket(")"));
					}
					else if (aChildRowsChildrens.size() == 2 ) {//may be able to convert to unicode ie., -alpha
						exp = createAndAddElementValueToExpression_asciiMathLibraryBlock(exp, aChildRowsChildrens.get(0).getNodeValue());
						exp = createAndAddElementValueToExpression_constraintParameter(exp, toStringFromUnicodeMI(variableName)); //variableName = aChildRowsChildrens.get(1).getNodeValue();
					}
					else
						throw new Exception("Not supported");
				}
			}
			else 
			
			
			//all mi(s): two or more <mi>s i.e, "xyz" as a varialbe <mrow><mi>x</mi><mi>y</mi><mi>z</mi></mrow>
			//negative number -11.7 <mrow><mo>-</mo><mn></mn></mrow> or positive number +11.7
			//negative variable <mrow><mo>-</mo><mi>x</mi></mrow> for "-x" <mrow><mo>-</mo><mi>x</mi><mi>y</mi></mrow> for "(-xy)"

			//<mrow><mi>c</mi><mo>-</mo><mi>d</mi> for "(c-d)"
			
			
			
			
			//all mis
			else if ( aChildRowsChildrens.get(0).getNodeName() == "mi" ){ //more than one mi's
				for ( int i = 0; i < aChildRowsChildrens.size(); i++) {
					variableName+=aChildRowsChildrens.get(i).getNodeValue();
				//not need to convert variableName to unicode because variableName.length() should be more than 1 for this case.
				Expression exp2 = createAndAddElementValueToExpression_constraintParameter(exp, variableName);
				if ( exp2 == null)
					throw new Exception ( variableName + " is not a constraint parameter.");
			}
			
			else c-d<mi>c<mo>-<mi>d etc...

	}
		*/
	
	/*private void processAChildren(Node aChild, Expression exp) throws Exception{
		
		String childNodeName = aChild.getNodeName();
		String variableName = "";
		if( childNodeName.equals("mi")){
			variableName = toStringFromUnicodeMI(aChild.getNodeValue());
			Expression exp2 = createAndAddElementValueToExpression_constraintParameter(exp, variableName);
			if ( exp2 == null)
				throw new Exception ( variableName + " is not a constraint parameter.");
		}
		else if ( childNodeName.equals("mn")){ 
			//if negative number <mo>-</mo> is before <msub> or <msup>
			//positive number
			exp.getOperand().add(getNumber(aChild,""));
		}
		else if ( childNodeName.equals("mrow")){
			List<Node> aChildRowsChildrens = getChildElementNodes(aChild);

			
			//all mi(s): two or more <mi>s i.e, "xyz" as a varialbe <mrow><mi>x</mi><mi>y</mi><mi>z</mi></mrow>
			//negative number -11.7 <mrow><mo>-</mo><mn></mn></mrow> or positive number +11.7
			//negative variable <mrow><mo>-</mo><mi>x</mi></mrow> for "-x" <mrow><mo>-</mo><mi>x</mi><mi>y</mi></mrow> for "(-xy)"

			//<mrow><mi>c</mi><mo>-</mo><mi>d</mi> for "(c-d)"
			
			if ( aChildRowsChildrens.get(0).getNodeName() == "mo"){ //- or +
				//negative number or positive number
				if ( aChildRowsChildrens.get(1).getNodeName() == "mn"){ //negativeNumber or positiveNumber
					exp.getOperand().add(getNumber(aChildRowsChildrens.get(1),aChildRowsChildrens.get(0).getNodeValue()));
				}
				else if ( aChildRowsChildrens.get(1).getNodeName() == "mi") { //negative or positive variable mi(s)
					for ( int i = 1; i < aChildRowsChildrens.size(); i++)
						variableName+=aChildRowsChildrens.get(i).getNodeValue();
					if (aChildRowsChildrens.size() >= 3 ) {//i.e., -ab ???????? surrend by ()
						exp.getOperand().add(createBracket("("));
						exp = createAndAddElementValueToExpression_asciiMathLibraryBlock(exp, aChildRowsChildrens.get(0).getNodeValue());
						exp = createAndAddElementValueToExpression_constraintParameter(exp, variableName);
						exp.getOperand().add(createBracket(")"));
					}
					else if (aChildRowsChildrens.size() == 2 ) {//may be able to convert to unicode ie., -alpha
						exp = createAndAddElementValueToExpression_asciiMathLibraryBlock(exp, aChildRowsChildrens.get(0).getNodeValue());
						exp = createAndAddElementValueToExpression_constraintParameter(exp, toStringFromUnicodeMI(variableName)); //variableName = aChildRowsChildrens.get(1).getNodeValue();
					}
					else
						throw new Exception("Not supported");
				}
			}
			else 
			
			
			//all mis
			else if ( aChildRowsChildrens.get(0).getNodeName() == "mi" ){ //more than one mi's
				for ( int i = 0; i < aChildRowsChildrens.size(); i++) {
					variableName+=aChildRowsChildrens.get(i).getNodeValue();
				//not need to convert variableName to unicode because variableName.length() should be more than 1 for this case.
				Expression exp2 = createAndAddElementValueToExpression_constraintParameter(exp, variableName);
				if ( exp2 == null)
					throw new Exception ( variableName + " is not a constraint parameter.");
			}
			
			//else c-d<mi>c<mo>-<mi>d etc...
		}
		else
			throw new Exception( childNodeName + " is not supported.");
		
		
	}
	//Element Value of number, negative number, variable, negative variable, surrounded by ()
	*/
	
	private String toStringFromUnicodeMO(String _s){
		String fromUnicode = Doc2InfixStringUtil.MO.get(_s);
		if ( fromUnicode != null && !fromUnicode.equals(_s))
			_s = fromUnicode; //replace _s
		return _s;
	}
	
	
	//convert to ie., /u... to "alpha" 
	//convert if necessary for mi
	private String toStringFromUnicodeMI(String _s){
	
		if (_s.length() == 1){
			String fromUnicode = Doc2InfixStringUtil.MI.get(_s);
			if ( fromUnicode != null && !fromUnicode.equals(_s))
				_s = fromUnicode;//replace _s
		}
		return _s;
	}
	//Expression return is not null
	private Expression  createExpression_handleSpecialmrowmi(Node n, Expression exp, String variableString) throws Exception {
		
		if ( variableString.equals("f")|| variableString.equals("g")){ //are <mi> tagged
			exp = createAndAddElementValueToExpression_asciiMathLibraryBlock(exp, variableString);
			if ( exp == null)
				throw new Exception (variableString + " should be defined in AsciiMathLibraryBlock.  Define it and please retry.");
		}
		else {
			variableString = toStringFromUnicodeMI(variableString);
			Expression exp2 = createAndAddElementValueToExpression_constraintParameter(exp, variableString); 
			if ( exp2 == null){ //variableString was not in
				exp2 = createAndAddElementValueToExpression_customFunction(exp, variableString);
				if (exp2 == null) {
					exp = handleSpecialmrowmi_customFunction(n, exp, variableString); //if null thrown exception
					//TODO: is it possible the below case "fun" can be a constraint parameter? if so need to handleSpecialmrowmi_constraintParameter too and previousWasCustom should be false	
					//<mrow>
				    //  <mi>f</mi>
				    //  <mi>u</mi>
				    //</mrow>
				    //<mi>n</mi>
					previousWasCustom = true; //see TODO above 
				}
				else {
					exp = exp2;
					previousWasCustom = true;
				}
			}
			else
				exp = exp2; //variableString was a constaint parameter
		}
		return exp;
	}
	/*
	 * 
	 * create Expression for the variableString but if not exist in constraint parameter or custom check if the below specical case
	 * variableString ="fu" why not inside mrow????
	<mrow>
      <mi>f</mi>
      <mi>u</mi>
    </mrow>
    <mi>n</mi>
	*/
	private Expression handleSpecialmrowmi_customFunction(Node n, Expression exp, String variableString) throws Exception{
		Node sibiling = nextElementNodeSibilig(n); //mrow's sibiling = childNode's parent's sibiling
		if ( sibiling.getNodeName().equals("mi")){
			variableString+=sibiling.getFirstChild().getNodeValue();
			exp = createAndAddElementValueToExpression_customFunction(exp, variableString);//looking from customFunction
			if ( exp == null){
				throw new Exception ("not able to find " + variableString + " in the constraint parameter nor Custom function.");
			}
			skipNextmi = true;
		}
		return exp; //not null 
	} 
	private LiteralString createBracket(String _s){
		LiteralString bracket = Application.getInstance().getProject().getElementsFactory().createLiteralStringInstance();
		bracket.setValue(_s);
		return bracket;
	}
	//call only when variableString.length != 0
	private Expression createAndAddElementValueToExpression_constraintParameter(Expression exp, String variableString){
		variableString = toStringFromUnicodeMI(variableString);
		ElementValue elemVal = createElementValueFromOperands(variableString, controller.getConstraintBlock());
		if ( elemVal != null)
			exp.getOperand().add(elemVal);
		else
			return null;
		return exp;
	}
	//call only when variableString.length != 0
	private Expression createAndAddElementValueToExpression_customFunction(Expression exp, String variableString){
		variableString = toStringFromUnicodeMI(variableString);//not likely necessary to convert
		ElementValue  elemVal = createElementValueFromOperation(variableString, AddContextMenuButton.customFuncBlock);
		if ( elemVal != null)
			exp.getOperand().add(elemVal);
		else
			return null;
		return exp;
	}
	private boolean isBracket(String moValue){
		if ( moValue.equals("(") || moValue.equals("[")|| moValue.equals("{") || moValue.equals("(:") || moValue.equals("{:")  //leftbrackets       
    			|| moValue.equals(")") || moValue.equals("]") ||moValue.equals("}") ||moValue.equals(":") ||moValue.equals("':") //right brackets 
    			|| moValue.equals(",") )  
			return true;
		else
			return false;
		
	}
	private Expression createAndAddElementValueToExpression_brackets(Expression exp, String moValue){
		if (isBracket(moValue)) {
			exp.getOperand().add(createBracket(moValue));
			return exp;
    	}
		else
			return null;
	}
	private Expression createAndAddElementValueToExpression_asciiMathLibraryBlock(Expression exp, String variableString){
		variableString = toStringFromUnicodeMI(variableString);
		ElementValue  elemVal = createElementValueFromOperation(variableString, AddContextMenuButton.asciiMathLibraryBlock);
		if ( elemVal != null)
			exp.getOperand().add(elemVal);
		else
			return null;
		return exp;
	}
	//Utility method
	private Node nextElementNodeSibilig(Node n){
		Node sibiling = null;
    	while( ((sibiling = n.getNextSibling()) != null) && sibiling.getNodeType() != Node.ELEMENT_NODE){
    		n = sibiling;
    	}
    	return sibiling;
	}
	private ValueSpecification getNumber(String _num){
		try{
			int lInteger = Integer.parseInt(_num);
			LiteralInteger lInt = createLiteralInteger();
			lInt.setValue(lInteger);
			return lInt;
		}
		catch (NumberFormatException e){}//ignore
		//double
		double lRealDouble = Double.parseDouble(_num);
		LiteralReal lReal = createLiteralReal();
		lReal.setValue(lRealDouble);
		return lReal;
	}
	private ValueSpecification getNumber(Node n, String prefix){
		try{
			int lInteger = Integer.parseInt(prefix + n.getFirstChild().getNodeValue());
			System.out.println("mn int" + lInteger);
			LiteralInteger lInt = createLiteralInteger();
			lInt.setValue(lInteger);
			return lInt;
		}
		catch (NumberFormatException e){}//ignore
		
		//double
		double lRealDouble = Double.parseDouble(prefix + n.getFirstChild().getNodeValue());
		LiteralReal lReal = createLiteralReal();
		lReal.setValue(lRealDouble);
		System.out.println("mn real: " + lRealDouble);
		return lReal;
	}
	//copy from http://stackoverflow.com/questions/5733931/java-string-unicode-value
	private static String escapeNonAscii(String str) {

		  StringBuilder retStr = new StringBuilder();
		  for(int i=0; i<str.length(); i++) {
		    int cp = Character.codePointAt(str, i);
		    int charCount = Character.charCount(cp);
		    if (charCount > 1) {
		      i += charCount - 1; // 2.
		      if (i >= str.length()) {
		        throw new IllegalArgumentException("truncated unexpectedly");
		      }
		    }

		    if (cp < 128) {
		      retStr.appendCodePoint(cp);
		    } else {
		      retStr.append(String.format("\\u%x", cp));
		    }
		  }
		  
		  //System.out.println(Charset.defaultCharset());//windows-1252
		  
		 /* String string = "\u03b3";
		  if ( str.equals(string))
			  System.out.println("same");
		  
		  byte[] utf8;
			try {
				utf8 = string.getBytes("UTF-8");
				string = new String(utf8, "UTF-8");
				System.out.println(string);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    
		*/   
		  /*String Title = StringEscapeUtils.unescapeJava(str);
		  System.out.println(Title);
		  
		  
		  Charset UTF_8 = Charset.forName("UTF-8");
		  String x =  new String(str.getBytes(UTF_8), UTF_8);
		  System.out.println(x);
		  */
		  return retStr.toString();
		}
	
	
}
