package gov.nasa.jpl.mbee.mdk.expression;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.List;

import org.antlr.v4.runtime.tree.ParseTree;
import org.w3c.dom.Document;

import com.nomagic.magicdraw.openapi.uml.SessionManager;
import com.nomagic.uml2.ext.magicdraw.classes.mdkernel.Constraint;
import com.nomagic.uml2.ext.magicdraw.classes.mdkernel.Element;
import com.nomagic.uml2.ext.magicdraw.classes.mdkernel.Property;
import com.nomagic.uml2.ext.magicdraw.classes.mdkernel.ValueSpecification;

import antlr.gov.nasa.jpl.mbee.mdk.expression.AsciiMathML2TreeTestxx.XX;
import net.sourceforge.jeuclid.LayoutContext;
import net.sourceforge.jeuclid.context.LayoutContextImpl;
import net.sourceforge.jeuclid.context.Parameter;
import net.sourceforge.jeuclid.converter.Converter;



public class MathEditorMain1Controller implements ActionListener {
	
	private MathEditorMain1Model model;
	private MathEditorMain1Controller controller;
	private MathEditorMain1  view;
	private ActionListener libraryButtonActionListener;
	
	private ListModelOperands operandsListModel;
	private ListModelOperations operationsListModel;
	
	public MathEditorMain1Controller(SelectedConstraintBlock _selectedConstraintBlock, Constraint _currentConstraint){
		
		model = new MathEditorMain1Model(_selectedConstraintBlock, _currentConstraint);
		controller = this;
		
		libraryButtonActionListener = ( event -> { //Updating Operations by asking a user to select asciiMathLibraryBlock and CustomFunction
				//when "Libraries..." button is pressed.
				LibrarySelector ls = new LibrarySelector();
				if(ls.openDialog()){
					model.setOperationAndCustromFunctions();
				}
				updateOperationsListModel(); //updating view's operations
			}
		);
	}
	public void showView() 
	{
		EventQueue.invokeLater(() -> {
				try {
					operandsListModel = new ListModelOperands(model.getOperands());
					operationsListModel = new ListModelOperations(model.getCombinedOperations());
					
					view = new MathEditorMain1(controller, operandsListModel, operationsListModel);	//with list selection
					view.initialize();
					
					//AutoComplete in the expression.  The suggestion only contains operands and custom functions.
					List<String> words = model.getOperandsInString();
					words.addAll(model.getCustomOperationsInString());
					new AutoCompleteJTextField( view.getTextField(), words);
					view.displayExpression(model.getEditExpression(), model.isStringExpression(), model.getName());
					
				} catch (Exception e) {
					e.printStackTrace();
				}
		});
	} 
	private void updateOperationsListModel(){
		this.operationsListModel.reset(model.getCombinedOperations());
	}
	public ActionListener getLibraryButtonActionListener() { return this.libraryButtonActionListener;} 
	
	public Element getConstraintBlock(){
		return model.getConstraintBlock();
	}
	public Element getCombinedOperation(String _operationString){
		return model.getCombinedOperation(_operationString);
	}
	public Element getOperand(String _operandString){
		return model.getOperand(_operandString);
	}
	public void addOperand(Property _newOperand){
		this.operandsListModel.add(_newOperand);
	}
	public void setName(String _name){
		this.model.setCurrentConstraintName(_name);
	}
	public void actionPerformed(ActionEvent e) {
		
		//TODO: add view's textfiled in change listener so not called twice by accident
		SessionManager.getInstance().createSession(e.getActionCommand());
		
		//action for confirm button
		if ( e.getActionCommand() == MathEditorMain1.CONFIRM){
			String textExpression = view.getTextExpression();
		
			AsciiMathParserOptions opt = new AsciiMathParserOptions();
	    	opt.setAddSourceAnnotation(true);
	    	

			//**************************RENDER EXPRESSION************************
			AsciiMathParser amp = new AsciiMathParser();
			Document docExp = amp.parseAsciiMath(textExpression/*, opt*/);
			
			
			String x = XX.printXML(docExp);	
			System.out.println(x);
			Doc2InfixString22222222 gg = new Doc2InfixString22222222(controller, docExp);
	    	try {
				ValueSpecification vs = gg.traverse0(null);
				Exp2StringExp transE2SE = new Exp2StringExp(vs);
				ValueSpecification vsNew = transE2SE.transform();
				vsNew.setOwner(this.model.currentConstraint);
				
			} catch (Exception e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();	
				Tree2UMLExpression.showMessage(e2.getMessage());
			}
	    	
			
			Converter getPic = Converter.getInstance();
			LayoutContextImpl l = (LayoutContextImpl) LayoutContextImpl.getDefaultLayoutContext();
			l.setParameter(Parameter.MATHSIZE, 30);
			BufferedImage pic;
			try {
				pic = getPic.render(docExp, (LayoutContext) l);	//LayoutContextImpl.getDefaultLayoutContext());
				view.setLblRenderIcon(pic);
				view.setTextExpressionCaretNotVisible();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			//*******************************************************************
			
			
			
			//WIPPPPPPPPPPPPPPPPPP
			/*AsciiMathML2Tree a2t = new AsciiMathML2Tree(textExpression);
			ParseTree pt = null;
			try {
			
				pt = a2t.parse();
				a2t.showTree();	//shows the LISP tree generated by an
			}
			catch (Exception pe){
				//parsing failed.
				Tree2UMLExpression.showMessage("Error: Problem in expression.");
				//save name in case it changed
				saveConstraintName();
				return;
			}
			//if ( pt != null ){
				ValueSpecification vs;
				ValueSpecification originalvs = this.model.currentConstraint.getSpecification();
				
				Tree2UMLExpression t2uml = null;
				if(view.selectedRadioButton() == MathEditorMain1.RadioButton.PREFIX){	//PARSE IN PREFIX NOTATION
					t2uml = new Tree2UMLExpression_Prefix(controller, pt, originalvs);
				} 
				else if (view.selectedRadioButton() == MathEditorMain1.RadioButton.INFIX){ //PARSE IN INFIX NOTATION
					//t2uml = new Tree2UMLExpression_InfixString2(controller, pt, originalvs);
					//WIPPPPPPPPPP
					t2uml = new Tree2UMLExpression_InfixString(controller, pt, originalvs);
				}
				else {	//PARSE IN INFIX NOTATION
					t2uml = new Tree2UMLExpression_Promela_ltl(controller, pt, originalvs);
				}
				try {
					vs = t2uml.parse();
				} catch (Exception e2) {
					//save name in case it changed
					saveConstraintName();
					return;
				}	
					
				if(!t2uml.getError()){
					
					//System.out.println("=====original specification");
					//System.out.println(originalvs);
					
					//ValueSpecification next = this.model.currentConstraint.getSpecification();
					//System.out.println("==========after specification======");
					//System.out.println(next);
					
							
					if (view.selectedRadioButton() == MathEditorMain1.RadioButton.INFIX){
						//***********************************2 STRING EXPRESSION******************************************
						Exp2StringExp transE2SE = new Exp2StringExp(vs);
						ValueSpecification vsNew = transE2SE.transform();
						vsNew.setOwner(this.model.currentConstraint);
					}
					else
						vs.setOwner(this.model.currentConstraint);
								
					//**************************RENDER EXPRESSION************************
					//AsciiMathParser amp = new AsciiMathParser();
					//Document docExp = amp.parseAsciiMath(textExpression);
					//Converter getPic = Converter.getInstance();
					//LayoutContextImpl l = (LayoutContextImpl) LayoutContextImpl.getDefaultLayoutContext();
					//l.setParameter(Parameter.MATHSIZE, 30);
					//BufferedImage pic;
					//try {
						//pic = getPic.render(docExp, (LayoutContext) l);	//LayoutContextImpl.getDefaultLayoutContext());
						//view.setLblRenderIcon(pic);
						//view.setTextExpressionCaretNotVisible();
					//} catch (IOException e1) {
					//	e1.printStackTrace();
					//}
					
					//*******************************************************************
				//}
			}*/
			//save name in case it changed
			saveConstraintName();
		}
		else if ( e.getActionCommand() == MathEditorMain1.nameButton.EDIT.buttonName()){ //press edit button for name
			this.view.setNameFileldEditable(true);
			this.view.setButtonName(MathEditorMain1.nameButton.SAVE.buttonName());
		}
		else if ( e.getActionCommand() == MathEditorMain1.nameButton.SAVE.buttonName()){ //press save button for name
			saveConstraintName();
		}
		SessionManager.getInstance().closeSession();
	}
	private void saveConstraintName(){
		this.model.setCurrentConstraintName(view.getName());
		this.view.setButtonName(MathEditorMain1.nameButton.EDIT.buttonName());
		this.view.setNameFileldEditable(false);
	}
	
}
