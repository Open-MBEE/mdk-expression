package gov.nasa.jpl.mbee.mdk.expression;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPath;
import org.antlr.v4.runtime.tree.ParseTree;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.nomagic.magicdraw.core.Application;
import com.nomagic.uml2.ext.magicdraw.classes.mdkernel.ElementValue;
import com.nomagic.uml2.ext.magicdraw.classes.mdkernel.Expression;
import com.nomagic.uml2.ext.magicdraw.classes.mdkernel.LiteralInteger;
import com.nomagic.uml2.ext.magicdraw.classes.mdkernel.LiteralReal;
import com.nomagic.uml2.ext.magicdraw.classes.mdkernel.LiteralString;
import com.nomagic.uml2.ext.magicdraw.classes.mdkernel.ValueSpecification;


public class Doc2InfixString22222222  extends Tree2UMLExpression {

	 
	private class Vs {
		
		public ValueSpecification value;
		public int offset;
		public Vs(ValueSpecification _value, int _offset){
			value = _value;
			offset = _offset;
		}
	}
	
	Document root;
	String stringExpression = "";
	
	private final String INFIX = "mfrac msub msup";
	
	private boolean skipNextmn = false;
	private boolean skipNextmi = false;
	private boolean previousWasCustom = false;
	
	public Doc2InfixString22222222(MathEditorMain1Controller _controller, Document _root){
		super(_controller, null, null);
		this.root = _root;
	}
	@Override
	protected ValueSpecification traverse0(ParseTree n) throws Exception { 
	    //DocumentElement document = DOMBuilder.getInstance().createJeuclidDom(root, true, true);
	    return(traverse0x(root));
	}
	protected ValueSpecification traverse0x(Node n) throws Exception {
		
		Expression exp = getExpression();
		Node node = root.getElementsByTagName("math").item(0);
		//Node node = root.getElementsByTagName("semantics").item(0);
		//stringExpression = root.getElementsByTagName("annotation").item(0).getFirstChild().getNodeValue();
		return processChildrens(node, exp);
	}

	private List<Node> getChildElementNodes(Node n)
	{
		List<Node> elementNodes = new ArrayList<Node>();
		NodeList nl = n.getChildNodes();
		Node nc;
 	    for (int i = 0; i < nl.getLength(); i++) {
 	           nc = nl.item(i);
 	           if (nc.getNodeType() == Node.ELEMENT_NODE){
 	        	   elementNodes.add(nc);
 	           }
 	    }
 	    return elementNodes;
	}
	private String getPositiveOrNegativeNumber(List<Node>nl, int startIndex)
	{
		String s = "";
		if ( nl.size() == 2 && nl.get(startIndex).getNodeName().equals("mo") && (nl.get(startIndex).getFirstChild().getNodeValue().equals("-") || nl.get(startIndex).getFirstChild().getNodeValue().equals("+"))){
			s+=nl.get(startIndex).getFirstChild().getNodeValue(); //+ or -
			if ( nl.get(startIndex+1).getNodeName().equals("mn")) { //number prefix with "+" or "-"
				s+= nl.get(startIndex+1).getFirstChild().getNodeValue();
				return s;
			}
		}
		return null;
	}
	
	private static Object[] getMisMns(List<Node> nl, int startIndex)
	{
		String s = "";
		String t;
		int i;
		for ( i = startIndex; i < nl.size(); i++ ){
			if( (t = nl.get(i).getNodeName()).equals("mi") || t.equals("mn"))
				s+= nl.get(i).getFirstChild().getNodeValue();
			else {
				break;
			}
		}
		return new Object[]{s, i}; //s = string (mi and mn) corrected, i = number of children consecutive mi or mn 
	}
		
	//f(x) or g(xy) then <mi>f</mi><mrow><mo>(</mo><mi>x</mi><mo>)</mo></mrow> then f is created from asciilibrary's f
	private boolean isNextSiblingMRowEnclosedbyBrackets(Node n) {
		try{
			Node sibling = n.getNextSibling();
			if ( sibling.getNodeName().equals("mrow")){
				List<Node>scs = getChildElementNodes(sibling);
				//at least 3 parameters "(" a parameter and ")" 
				if ( scs.size() >= 3 && scs.get(0).getNodeName().equals("mo") && scs.get(0).getFirstChild().getNodeValue().equals("(") 
					&& scs.get(scs.size()-1).getNodeName().equals("mo") && scs.get(scs.size()-1).getFirstChild().getNodeValue().equals(")"))
					return true;
			}
			return false;
		}
		catch (Exception e) {return false;}
	}
	
	
	private Vs getPositiveOrNegativeNumber(Node n)
	{
		String s = "";
		int i = -1;
		if (n.getNodeName().equals("mo") && (
				n.getFirstChild().getNodeValue().equals("-")
				||n.getFirstChild().getNodeValue().equals("+"))) {
			s+=n.getFirstChild().getNodeValue(); // + or -
			i++;
		}
		else
			return null;
		if ( n.getNextSibling() != null && n.getNextSibling().getNodeName().equals("mn")){
			s+=n.getNextSibling().getFirstChild().getNodeValue();
			return new Vs( getNumber(s), ++i);
		}
		return null;
	}
	private ValueSpecification createAndAddElementValueBracket(String moValue){
		if (isBracket(moValue)) 
			return createBracket(moValue);
		else
			return null;
	}
	
	private Vs getMisMns(Node n, boolean searchSibiling) throws Exception
	{
		String s = "";
		String t;
		int i = -1;
		while ((t = n.getNodeName()).equals("mi") || t.equals("mn")){
			s+= n.getFirstChild().getNodeValue();
			i++;
			if (!searchSibiling)
			  break;
			n = n.getNextSibling();
			if (n == null)
				break;
		}
		if ( s.length() == 1) {
			if ( s.equals("f")|| s.equals("g")) {
				if (isNextSiblingMRowEnclosedbyBrackets(n)){ //are <mi> tagged
					ElementValue ev = createElementValueFromOperation(s, AddContextMenuButton.asciiMathLibraryBlock);
					if ( ev == null)
						throw new Exception ("\"" + s + "\" should be defined in AsciiMathLibraryBlock.  Define it and please retry.");
					return new Vs(ev, i); //f(x) or g(x) etc...
				}
				//s is "f" or "g" a constraint parameter
			}
			else 
				s = this.toStringFromUnicodeMI(s);
		}
		else
			s = this.toStringFromUnicodeMI(s);
		//search from constraintblock
		ElementValue ev = createElementValueFromOperands(s, controller.getConstraintBlock());
		if ( ev == null) {//may be customFunction
			ev = createElementValueFromOperation(s, AddContextMenuButton.customFuncBlock);
			if (ev == null)
				throw new Exception( "\"" + s + "\" is not a constraint parameter or custom function.");
			return new Vs(ev, i); //custom function
		}
		else
			return new Vs(ev, i); //is constraint parameter
	}
	
	//TODO may need to imporive
	private boolean needBrackets(List<Node> childNodes){
			if ( childNodes.get(0).getNodeName().equals("mo") && isBracket(childNodes.get(0).getFirstChild().getNodeValue()))//1st mrow child is a bracket "(" etc..
				return false;
			
			/*
			 *   <mrow>
      				<msubsup>
        <mi>z</mi>
        <mn>12</mn>
        <mn>34</mn>
      </msubsup>
    </mrow>
			 */
			else if ( childNodes.size() == 1) 
				return false;
			//else if if 2 childNodes of number like -100 +10, then () may not needed  
			else
				return true;
//			
//			else if ( isAllChildrenHaveSameNodeName(n))
//				return false;
//			else {
//				String s = getPositiveOrNegativeNumber(nl, 0);
//				if ( s!= null && s.length() == nl.size())
//					return false; //it is positive or negative number
//				if ( nl.get(0).getNodeName().equals("mo") && (nl.get(0).getFirstChild().getNodeValue().equals("-")||nl.get(0).getFirstChild().getNodeValue().equals("+"))){
//					s = getMis(nl, 1); //variable prefix by - or +
//					if ( s.length() == 2 /*-a or +a*/ && s.length() == nl.size())
//						return false;
//					else if ( (s.length()+1) == nl.size())
//						return true; //(-ab)
//				}
//				return false; //ab+c <mrow><msub><mi>a</mi><mi>b<mi></msub><mrow> a_b
//			}
	}
	
	
	private Vs processNode(Node n, boolean searchSibiling) throws Exception{
		
		//List<Node> nl = getChildElementNodes(n);
		//int startIndex = 0;
		Object[] vis;
		String temp;
		boolean tempb;
		Vs tempVs;
			if ( n.getNodeName().equals("mn")) //number
				return new Vs(getNumber(n, ""), 0); //nextIndex = i+1 automatically
			else if((tempVs = getPositiveOrNegativeNumber(n)) != null){ //number prefix by + or -
				return tempVs;
			} 
			else if ( n.getNodeName().equals("mo")) {//operator
				temp = n.getFirstChild().getNodeValue(); //movalue
				ValueSpecification b = createAndAddElementValueBracket(temp); //brackets and comma do not need conversion
				if ( b != null) //it was bracket or comma
					return new Vs(b, 0);
				else {
					
					//\u2192 can be vec, ->, or rarr.  for vec's case its parent is mover.  rarr is return as "->" because no way to distinguish(?)
					if ( temp.equals("\u2192")){
						if ( n.getParentNode().getNodeName().equals("mover"))
							temp = "vec";
						else
							temp = "->"; // rarr and -> both save uml as "->"
					}
					else
						temp = toStringFromUnicodeMO(temp);
					
					ElementValue ev = createElementValueFromOperation(temp, AddContextMenuButton.asciiMathLibraryBlock);
					if (ev == null){
						throw new Exception("\"" + temp + "\" is not in AsciiMath Library");
					}
					return new Vs(ev, 0);
				}
			}
			else if (n.getNodeName().equals("mi"))
				return getMisMns(n, searchSibiling);
			else if (n.getNodeName().equals("mrow")){
				Expression expNew = getExpression();
				List<Node> nl = getChildElementNodes(n); 
				if ( tempb = needBrackets(nl))
					expNew.getOperand().add(createBracket("("));
				for ( int i = 0; i < nl.size(); i++){
					tempVs = processNode(nl.get(i), searchSibiling);
					if ( tempVs == null)
						throw new Exception ("Not supported - problem in " + nl.get(i).getNodeName());
					expNew.getOperand().add(tempVs.value);
					i = i + tempVs.offset;
				}
				if ( tempb )expNew.getOperand().add(createBracket(")"));
				return new Vs(expNew, 0);
			}
			else if ( Doc2InfixStringUtil.COMMAND_W_ARGS.get(n.getNodeName()) == Doc2InfixStringUtil.TType.UNARY) {//msqrt)
				Expression expNew = getExpression();
				//ie., sqrt
				ElementValue ev = createElementValueFromOperation(Doc2InfixStringUtil.FN.get(n.getNodeName()), AddContextMenuButton.asciiMathLibraryBlock);
				expNew.getOperand().add(ev);
				
				List<Node> nl = getChildElementNodes(n); 
				if ( nl.size() != 1)
					throw new Exception ("Not supported - problem in " + n + ". The function should have one argument.");
				
				tempVs = processNode(nl.get(0), false);
				if ( tempVs == null)
					throw new Exception ("Not supported - problem in " + nl.get(0).getNodeName());
				expNew.getOperand().add(tempVs.value);
				
				return new Vs(expNew, 0);
			}
			else if ( Doc2InfixStringUtil.COMMAND_W_ARGS.get(n.getNodeName()) == Doc2InfixStringUtil.TType.BINARY) {//root 
				Expression expNew = getExpression();
				
				ElementValue ev = createElementValueFromOperation(Doc2InfixStringUtil.FN.get(n.getNodeName()), AddContextMenuButton.asciiMathLibraryBlock);
				expNew.getOperand().add(ev);
				
				List<Node> nl = getChildElementNodes(n); 
				if( nl.size() != 2) { //root and one argument 
					throw new Exception ("Not supported - problem in " + n + ". The function should have two arguments.");
				}
				for ( int i = 0; i < 2; i++){
					tempVs = processNode(nl.get(i), false);
					if ( tempVs == null)
						throw new Exception ("Not supported - problem in " + nl.get(i).getNodeName());
					expNew.getOperand().add(tempVs.value);
				}
				return new Vs(expNew, 0);
			}
			//both are mover/munder but hat case requires flipping 2 childrens and lim case is not 
			/*<mover>  
		      <mrow>
		        <mi>a</mi>
		        <mi>b</mi>
		      </mrow>
		      <mo>^</mo>
		    </mover>
		    
		    <munder>
		      <mo>lim</mo>
		      <mrow>
		        <mi>h</mi>
		        <mo>?</mo>
		        <mn>0</mn>
		      </mrow>
		    </munder>
			*/
			else if ( Doc2InfixStringUtil.COMMAND_W_ARGS.get(n.getNodeName()) == Doc2InfixStringUtil.TType.MOVERORMUNDER) {//
				Expression expNew = getExpression();
				List<Node> nl = getChildElementNodes(n); 
				if(nl.size() != 2) { //2 children arguments 
					throw new Exception ("Not supported - problem in " + n + ". The function should have two arguments.");
				}
				for ( int i = 0; i < 2; i++){
					tempVs = processNode(nl.get(i), false);
					if ( tempVs == null)
						throw new Exception ("Not supported - problem in " + nl.get(i).getNodeName());
					expNew.getOperand().add(tempVs.value);
				}
				//flip exp  hat bar vec dot ddot ul (ie., <mover><mi>a</mi><mo>vec</mo></mover> "a vec" to "vec a" , "ab"bar to bar(ab)", "aul" to "ula"
				//no need to add mover(^) or munder(_)
				if (n.getChildNodes().item(1).getNodeName().equals("mo")){
					ValueSpecification exp1 = expNew.getOperand().get(0);
					ValueSpecification exp2 = expNew.getOperand().get(1);
					expNew.getOperand().clear();
					expNew.getOperand().add(exp2); 
					//expNew = createAndAddElementValueToExpression_asciiMathLibraryBlock(expNew, Doc2InfixStringUtil.FN.get(nl.get(i).getNodeName())); //mover not need to add this cases
					expNew.getOperand().add(exp1);
				}
				else{
					///*lim_(x->0) <munder> <mo>lim</mo><mrow><mi>x</mi><mo>-></mo><mn>0</mn></mrow></munder>*/
					//adding "^" or "-" to expNew (ab to a^b or a_b)
					ValueSpecification exp1 = expNew.getOperand().get(1);
					expNew.getOperand().remove(1); 
					expNew.getOperand().add(createElementValueFromOperation(Doc2InfixStringUtil.FN.get(n.getNodeName()), AddContextMenuButton.asciiMathLibraryBlock)); //adding ^ or _
					expNew.getOperand().add(exp1);
				}
				return new Vs(expNew, 0);
			}
			else if ( Doc2InfixStringUtil.COMMAND_W_ARGS.get(n.getNodeName()) == Doc2InfixStringUtil.TType.INFIX) { //mfrac, msub msup
				Expression expNew = getExpression();
				
//TODO test here
				List<Node> nl = getChildElementNodes(n); 
				if(nl.size() != 2) { //2 children arguments 
					throw new Exception ("Not supported - problem in " + n + ". The function should have two arguments.");
				}
				tempVs = processNode(nl.get(0), false);
				if ( tempVs == null)
					throw new Exception ("Not supported - problem in " + nl.get(0).getNodeName());
				expNew.getOperand().add(tempVs.value);
				//adding "^" or "-" to expNew (ab to a^b or a_b)
				expNew.getOperand().add(createElementValueFromOperation(Doc2InfixStringUtil.FN.get(n.getNodeName()), AddContextMenuButton.asciiMathLibraryBlock)); //adding ^ or _ or /
				tempVs = processNode(nl.get(1), false);
				if ( tempVs == null)
					throw new Exception ("Not supported - problem in " + nl.get(1).getNodeName());
				expNew.getOperand().add(tempVs.value);
				return new Vs(expNew, 0);
			}

			
			else if (n.getNodeName().equals("msubsup") || n.getNodeName().equals("munderover")){
				Expression expNew = getExpression();
				List<Node> nl = getChildElementNodes(n); 
				if(nl.size() != 3) { //3 children arguments 
					throw new Exception ("Not supported - problem in " + n.getNodeName() + ". The function should have three arguments.");
				}
				//adding "_" or "^" to expNew  (abc to a_b^c)
				for ( int i = 0; i < 3; i++){
					tempVs = processNode(nl.get(i), false);
					if ( tempVs == null)
						throw new Exception ("Not supported - problem in " + nl.get(i).getNodeName());
					expNew.getOperand().add(tempVs.value);
					if ( i == 0)
						expNew = createAndAddElementValueToExpression_asciiMathLibraryBlock(expNew, "_");//"^ or "_"
					else if ( i == 1)
						expNew = createAndAddElementValueToExpression_asciiMathLibraryBlock(expNew, "^");//"^ or "_"
				}
				return new Vs(expNew, 0);
			}
			else if (n.getNodeName().equals("mtd")){
				Expression expNew = getExpression();
				List<Node> nl = getChildElementNodes(n); 
				for ( int i = 0; i < nl.size(); i++) { 
					tempVs = processNode(nl.get(i), true);
					if ( tempVs == null)
						throw new Exception ("Not supported - problem in " + nl.get(i).getNodeName());
					expNew.getOperand().add(tempVs.value);
					i = i + tempVs.offset;
				}
				return new Vs(expNew, 0);
			}
			else if ( n.getNodeName().equals("mtr")){
				Expression expNew = getExpression();
				List<Node> nl = getChildElementNodes(n); 
				for ( int i = 0; i < nl.size(); i++) { 
					tempVs = processNode(nl.get(i), false);
					if ( tempVs == null)
						throw new Exception ("Not supported - problem in " + nl.get(i).getNodeName());
					expNew.getOperand().add(tempVs.value);
					i = i + tempVs.offset;
				}
				return new Vs(addCommandBetweenOperands(expNew,  getEnclosedBracketSet(n.getParentNode())), 0);
			}
			else if (n.getNodeName().equals("mtable")){
				Expression expNew = getExpression();
				List<Node> nl = getChildElementNodes(n); 
				for ( int i = 0; i < nl.size(); i++) { 
					tempVs = processNode(nl.get(i), false);
					if ( tempVs == null)
						throw new Exception ("Not supported - problem in " + nl.get(i).getNodeName());
					expNew.getOperand().add(tempVs.value);
					i = i + tempVs.offset;
				}
				return new Vs(addCommandBetweenOperands(expNew,  null), 0);
				
			}
			else 
				throw new Exception ("\""+ n.getNodeName() + "\" not supported.");
			
	 }
	 Expression processChildrens(Node n, Expression exp) throws Exception{
		
		List<Node> nl = getChildElementNodes(n);
		Vs vs;
		for ( int i = 0; i < nl.size(); i++){
			vs = processNode(nl.get(i), true);
			exp.getOperand().add(vs.value);
			i = i + vs.offset;
		}
		return exp;
	}
	
	
	private Object[] getEnclosedBracketSet(Node n){
		while ( !n.getNodeName().equals("mtable")){
			n = n.getParentNode();
		}
		//n is mtable
		//assmes n.getNextSibiling has ending bracket of the same type.
		if (n.getPreviousSibling().getNodeName().equals("mo")){
			String s = n.getPreviousSibling().getFirstChild().getNodeValue();
			if ( s.equals("["))
				return new Object[] {"[", "]"};
			else if ( s.equals("("))
				return new Object[] {"(", ")"};
			else if ( s.equals("{"))
				return new Object[] {"{", "}"};
			else if ( s.equals("(:"))
				return new Object[] {"(:", ":)"};
			else if ( s.equals("{:"))
				return new Object[] {"{:", ":}"};
		}
		return null;
	
	}
	private Expression addCommandBetweenOperands(Expression _exp, Object[] enclosedBrackets ){
		Expression expNew = getExpression();
		if ( enclosedBrackets != null)
			expNew.getOperand().add(createBracket((String)enclosedBrackets[0]));
		List<ValueSpecification> tempList = new ArrayList<ValueSpecification>();
		for ( int j = 0; j < _exp.getOperand().size(); j++) {
			if (j != 0) 
				tempList.add(createBracket(","));
			tempList.add(_exp.getOperand().get(j));
		}
		for ( int i = 0; i < tempList.size(); i++)
			expNew.getOperand().add(tempList.get(i));
		if ( enclosedBrackets != null)
			expNew.getOperand().add(createBracket((String)enclosedBrackets[1]));
		return expNew;
	}
	
	
	//TODO may need to imporive
	private boolean needBrackets(Node n){
		List<Node> nl = getChildElementNodes(n);
		if ( nl.get(0).getNodeName().equals("mo") && isBracket(nl.get(0).getFirstChild().getNodeValue()))//1st mrow child is a bracket "(" etc..
			return false;
		//else if ( nl.size() == 1)
			//return false;
		else
			return true;
//		
//		else if ( isAllChildrenHaveSameNodeName(n))
//			return false;
//		else {
//			String s = getPositiveOrNegativeNumber(nl, 0);
//			if ( s!= null && s.length() == nl.size())
//				return false; //it is positive or negative number
//			if ( nl.get(0).getNodeName().equals("mo") && (nl.get(0).getFirstChild().getNodeValue().equals("-")||nl.get(0).getFirstChild().getNodeValue().equals("+"))){
//				s = getMis(nl, 1); //variable prefix by - or +
//				if ( s.length() == 2 /*-a or +a*/ && s.length() == nl.size())
//					return false;
//				else if ( (s.length()+1) == nl.size())
//					return true; //(-ab)
//			}
//			return false; //ab+c <mrow><msub><mi>a</mi><mi>b<mi></msub><mrow> a_b
//		}
	}
	private boolean isAllChildrenHaveSameNodeName(Node n){
		List<Node> nl = getChildElementNodes(n);
		String firstNodeName = nl.get(0).getNodeName();
		for (int i = 1; i < nl.size(); i++){
			if ( !nl.get(i).getNodeName().equals(firstNodeName))
				return false;
		}
		return true;
	}
		/*
		
		if ( nl.get(0).getNodeName().equals("mo")) { // - or +
			if ( nl.get(1).getNodeName().equals("mn"))
				exp.getOperand().add(getNumber(nl.get(1), nl.get(0).getNodeValue())); //- or + number
			else if (nl.get(1).getNodeName().equals("mi")){ // - or + varaiables mi(s)
				String s = getMis(nl, 1);
				exp = createAndAddElementValueToExpression_asciiMathLibraryBlock(exp, toStringFromUnicodeMI(s));
				int nextIndex = s.length();
			}
		}
		
		
		
		if ( aChildRowsChildrens.get(0).getNodeName() == "mo"){ //- or +
				//negative number or positive number
				if ( aChildRowsChildrens.get(1).getNodeName() == "mn"){ //negativeNumber or positiveNumber
					exp.getOperand().add(getNumber(aChildRowsChildrens.get(1),aChildRowsChildrens.get(0).getNodeValue()));
				}
				else if ( aChildRowsChildrens.get(1).getNodeName() == "mi") { //negative or positive variable mi(s)
					for ( int i = 1; i < aChildRowsChildrens.size(); i++)
						variableName+=aChildRowsChildrens.get(i).getNodeValue();
					if (aChildRowsChildrens.size() >= 3 ) {//i.e., -ab ???????? surrend by ()
						exp.getOperand().add(createBracket("("));
						exp = createAndAddElementValueToExpression_asciiMathLibraryBlock(exp, aChildRowsChildrens.get(0).getNodeValue());
						exp = createAndAddElementValueToExpression_constraintParameter(exp, variableName);
						exp.getOperand().add(createBracket(")"));
					}
					else if (aChildRowsChildrens.size() == 2 ) {//may be able to convert to unicode ie., -alpha
						exp = createAndAddElementValueToExpression_asciiMathLibraryBlock(exp, aChildRowsChildrens.get(0).getNodeValue());
						exp = createAndAddElementValueToExpression_constraintParameter(exp, toStringFromUnicodeMI(variableName)); //variableName = aChildRowsChildrens.get(1).getNodeValue();
					}
					else
						throw new Exception("Not supported");
				}
			}
			else 
			
			
			//all mi(s): two or more <mi>s i.e, "xyz" as a varialbe <mrow><mi>x</mi><mi>y</mi><mi>z</mi></mrow>
			//negative number -11.7 <mrow><mo>-</mo><mn></mn></mrow> or positive number +11.7
			//negative variable <mrow><mo>-</mo><mi>x</mi></mrow> for "-x" <mrow><mo>-</mo><mi>x</mi><mi>y</mi></mrow> for "(-xy)"

			//<mrow><mi>c</mi><mo>-</mo><mi>d</mi> for "(c-d)"
			
			
			
			
			//all mis
			else if ( aChildRowsChildrens.get(0).getNodeName() == "mi" ){ //more than one mi's
				for ( int i = 0; i < aChildRowsChildrens.size(); i++) {
					variableName+=aChildRowsChildrens.get(i).getNodeValue();
				//not need to convert variableName to unicode because variableName.length() should be more than 1 for this case.
				Expression exp2 = createAndAddElementValueToExpression_constraintParameter(exp, variableName);
				if ( exp2 == null)
					throw new Exception ( variableName + " is not a constraint parameter.");
			}
			
			else c-d<mi>c<mo>-<mi>d etc...

	}
		*/
	
	/*private void processAChildren(Node aChild, Expression exp) throws Exception{
		
		String childNodeName = aChild.getNodeName();
		String variableName = "";
		if( childNodeName.equals("mi")){
			variableName = toStringFromUnicodeMI(aChild.getNodeValue());
			Expression exp2 = createAndAddElementValueToExpression_constraintParameter(exp, variableName);
			if ( exp2 == null)
				throw new Exception ( variableName + " is not a constraint parameter.");
		}
		else if ( childNodeName.equals("mn")){ 
			//if negative number <mo>-</mo> is before <msub> or <msup>
			//positive number
			exp.getOperand().add(getNumber(aChild,""));
		}
		else if ( childNodeName.equals("mrow")){
			List<Node> aChildRowsChildrens = getChildElementNodes(aChild);

			
			//all mi(s): two or more <mi>s i.e, "xyz" as a varialbe <mrow><mi>x</mi><mi>y</mi><mi>z</mi></mrow>
			//negative number -11.7 <mrow><mo>-</mo><mn></mn></mrow> or positive number +11.7
			//negative variable <mrow><mo>-</mo><mi>x</mi></mrow> for "-x" <mrow><mo>-</mo><mi>x</mi><mi>y</mi></mrow> for "(-xy)"

			//<mrow><mi>c</mi><mo>-</mo><mi>d</mi> for "(c-d)"
			
			if ( aChildRowsChildrens.get(0).getNodeName() == "mo"){ //- or +
				//negative number or positive number
				if ( aChildRowsChildrens.get(1).getNodeName() == "mn"){ //negativeNumber or positiveNumber
					exp.getOperand().add(getNumber(aChildRowsChildrens.get(1),aChildRowsChildrens.get(0).getNodeValue()));
				}
				else if ( aChildRowsChildrens.get(1).getNodeName() == "mi") { //negative or positive variable mi(s)
					for ( int i = 1; i < aChildRowsChildrens.size(); i++)
						variableName+=aChildRowsChildrens.get(i).getNodeValue();
					if (aChildRowsChildrens.size() >= 3 ) {//i.e., -ab ???????? surrend by ()
						exp.getOperand().add(createBracket("("));
						exp = createAndAddElementValueToExpression_asciiMathLibraryBlock(exp, aChildRowsChildrens.get(0).getNodeValue());
						exp = createAndAddElementValueToExpression_constraintParameter(exp, variableName);
						exp.getOperand().add(createBracket(")"));
					}
					else if (aChildRowsChildrens.size() == 2 ) {//may be able to convert to unicode ie., -alpha
						exp = createAndAddElementValueToExpression_asciiMathLibraryBlock(exp, aChildRowsChildrens.get(0).getNodeValue());
						exp = createAndAddElementValueToExpression_constraintParameter(exp, toStringFromUnicodeMI(variableName)); //variableName = aChildRowsChildrens.get(1).getNodeValue();
					}
					else
						throw new Exception("Not supported");
				}
			}
			else 
			
			
			//all mis
			else if ( aChildRowsChildrens.get(0).getNodeName() == "mi" ){ //more than one mi's
				for ( int i = 0; i < aChildRowsChildrens.size(); i++) {
					variableName+=aChildRowsChildrens.get(i).getNodeValue();
				//not need to convert variableName to unicode because variableName.length() should be more than 1 for this case.
				Expression exp2 = createAndAddElementValueToExpression_constraintParameter(exp, variableName);
				if ( exp2 == null)
					throw new Exception ( variableName + " is not a constraint parameter.");
			}
			
			//else c-d<mi>c<mo>-<mi>d etc...
		}
		else
			throw new Exception( childNodeName + " is not supported.");
		
		
	}
	//Element Value of number, negative number, variable, negative variable, surrounded by ()
	*/
	
	private String toStringFromUnicodeMO(String _s){
		String fromUnicode = Doc2InfixStringUtil.MO.get(_s);
		if ( fromUnicode != null && !fromUnicode.equals(_s))
			_s = fromUnicode; //replace _s
		return _s;
	}
	
	
	//convert to ie., /u... to "alpha" 
	//convert if necessary for mi
	private String toStringFromUnicodeMI(String _s){
	
		if (_s.length() == 1){
			String fromUnicode = Doc2InfixStringUtil.MI.get(_s);
			if ( fromUnicode != null && !fromUnicode.equals(_s))
				_s = fromUnicode;//replace _s
		}
		return _s;
	}
	//Expression return is not null
	private Expression  createExpression_handleSpecialmrowmi(Node n, Expression exp, String variableString) throws Exception {
		
		if ( variableString.equals("f")|| variableString.equals("g")){ //are <mi> tagged
			exp = createAndAddElementValueToExpression_asciiMathLibraryBlock(exp, variableString);
			if ( exp == null)
				throw new Exception (variableString + " should be defined in AsciiMathLibraryBlock.  Define it and please retry.");
		}
		else {
			variableString = toStringFromUnicodeMI(variableString);
			Expression exp2 = createAndAddElementValueToExpression_constraintParameter(exp, variableString); 
			if ( exp2 == null){ //variableString was not in
				exp2 = createAndAddElementValueToExpression_customFunction(exp, variableString);
				if (exp2 == null) {
					exp = handleSpecialmrowmi_customFunction(n, exp, variableString); //if null thrown exception
					//TODO: is it possible the below case "fun" can be a constraint parameter? if so need to handleSpecialmrowmi_constraintParameter too and previousWasCustom should be false	
					//<mrow>
				    //  <mi>f</mi>
				    //  <mi>u</mi>
				    //</mrow>
				    //<mi>n</mi>
					previousWasCustom = true; //see TODO above 
				}
				else {
					exp = exp2;
					previousWasCustom = true;
				}
			}
			else
				exp = exp2; //variableString was a constaint parameter
		}
		return exp;
	}
	/*
	 * 
	 * create Expression for the variableString but if not exist in constraint parameter or custom check if the below specical case
	 * variableString ="fu" why not inside mrow????
	<mrow>
      <mi>f</mi>
      <mi>u</mi>
    </mrow>
    <mi>n</mi>
	*/
	private Expression handleSpecialmrowmi_customFunction(Node n, Expression exp, String variableString) throws Exception{
		Node sibiling = nextElementNodeSibilig(n); //mrow's sibiling = childNode's parent's sibiling
		if ( sibiling.getNodeName().equals("mi")){
			variableString+=sibiling.getFirstChild().getNodeValue();
			exp = createAndAddElementValueToExpression_customFunction(exp, variableString);//looking from customFunction
			if ( exp == null){
				throw new Exception ("not able to find " + variableString + " in the constraint parameter nor Custom function.");
			}
			skipNextmi = true;
		}
		return exp; //not null 
	} 
	private LiteralString createBracket(String _s){
		LiteralString bracket = Application.getInstance().getProject().getElementsFactory().createLiteralStringInstance();
		bracket.setValue(_s);
		return bracket;
	}
	//call only when variableString.length != 0
	private Expression createAndAddElementValueToExpression_constraintParameter(Expression exp, String variableString){
		variableString = toStringFromUnicodeMI(variableString);
		ElementValue elemVal = createElementValueFromOperands(variableString, controller.getConstraintBlock());
		if ( elemVal != null)
			exp.getOperand().add(elemVal);
		else
			return null;
		return exp;
	}
	//call only when variableString.length != 0
	private Expression createAndAddElementValueToExpression_customFunction(Expression exp, String variableString){
		variableString = toStringFromUnicodeMI(variableString);//not likely necessary to convert
		ElementValue  elemVal = createElementValueFromOperation(variableString, AddContextMenuButton.customFuncBlock);
		if ( elemVal != null)
			exp.getOperand().add(elemVal);
		else
			return null;
		return exp;
	}
	private boolean isBracket(String moValue){
		if ( moValue.equals("(") || moValue.equals("[")|| moValue.equals("{") || moValue.equals("(:") || moValue.equals("{:")  //leftbrackets       
    			|| moValue.equals(")") || moValue.equals("]") ||moValue.equals("}") ||moValue.equals(":)") ||moValue.equals(":}") //right brackets 
    			|| moValue.equals(",") )  
			return true;
		else
			return false;
		
	}
	private Expression createAndAddElementValueToExpression_brackets(Expression exp, String moValue){
		if (isBracket(moValue)) {
			exp.getOperand().add(createBracket(moValue));
			return exp;
    	}
		else
			return null;
	}
	private Expression createAndAddElementValueToExpression_asciiMathLibraryBlock(Expression exp, String variableString){
		variableString = toStringFromUnicodeMI(variableString);
		ElementValue  elemVal = createElementValueFromOperation(variableString, AddContextMenuButton.asciiMathLibraryBlock);
		if ( elemVal != null)
			exp.getOperand().add(elemVal);
		else
			return null;
		return exp;
	}
	//Utility method
	private Node nextElementNodeSibilig(Node n){
		Node sibiling = null;
    	while( ((sibiling = n.getNextSibling()) != null) && sibiling.getNodeType() != Node.ELEMENT_NODE){
    		n = sibiling;
    	}
    	return sibiling;
	}
	private ValueSpecification getNumber(String _num){
		try{
			int lInteger = Integer.parseInt(_num);
			LiteralInteger lInt = createLiteralInteger();
			lInt.setValue(lInteger);
			return lInt;
		}
		catch (NumberFormatException e){}//ignore
		//double
		double lRealDouble = Double.parseDouble(_num);
		LiteralReal lReal = createLiteralReal();
		lReal.setValue(lRealDouble);
		return lReal;
	}
	private ValueSpecification getNumber(Node n, String prefix){
		try{
			int lInteger = Integer.parseInt(prefix + n.getFirstChild().getNodeValue());
			LiteralInteger lInt = createLiteralInteger();
			lInt.setValue(lInteger);
			return lInt;
		}
		catch (NumberFormatException e){}//ignore
		
		//double
		double lRealDouble = Double.parseDouble(prefix + n.getFirstChild().getNodeValue());
		LiteralReal lReal = createLiteralReal();
		lReal.setValue(lRealDouble);
		return lReal;
	}
	//copy from http://stackoverflow.com/questions/5733931/java-string-unicode-value
	private static String escapeNonAscii(String str) {

		  StringBuilder retStr = new StringBuilder();
		  for(int i=0; i<str.length(); i++) {
		    int cp = Character.codePointAt(str, i);
		    int charCount = Character.charCount(cp);
		    if (charCount > 1) {
		      i += charCount - 1; // 2.
		      if (i >= str.length()) {
		        throw new IllegalArgumentException("truncated unexpectedly");
		      }
		    }

		    if (cp < 128) {
		      retStr.appendCodePoint(cp);
		    } else {
		      retStr.append(String.format("\\u%x", cp));
		    }
		  }
		  
		  //System.out.println(Charset.defaultCharset());//windows-1252
		  
		 /* String string = "\u03b3";
		  if ( str.equals(string))
			  System.out.println("same");
		  
		  byte[] utf8;
			try {
				utf8 = string.getBytes("UTF-8");
				string = new String(utf8, "UTF-8");
				System.out.println(string);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    
		*/   
		  /*String Title = StringEscapeUtils.unescapeJava(str);
		  System.out.println(Title);
		  
		  
		  Charset UTF_8 = Charset.forName("UTF-8");
		  String x =  new String(str.getBytes(UTF_8), UTF_8);
		  System.out.println(x);
		  */
		  return retStr.toString();
		}
		
}
